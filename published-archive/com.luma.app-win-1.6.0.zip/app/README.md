# Luma

A quiet weight and calorie tracker for Windows and Android, built with
[Flet](https://flet.dev). Luma is the redesigned successor to the FitFriend
single-file web app — same data, same features, rebuilt as a real application.

## Running it

```bash
flet run app/main.py
```

Add `--web` to run it in a browser instead of a desktop window.

Your data lives in one JSON file under the platform's application-support
directory (`%APPDATA%\Luma\luma-data.json` on Windows). Set `LUMA_DATA_DIR` to
put it somewhere else — useful for testing against a scratch copy.

## The four screens

| Screen     | What it is for                                                        |
| ---------- | --------------------------------------------------------------------- |
| **Today**  | Log the day. On Android one metric is the hero and the other collapses to a tappable strip, with the Weight / Eaten switch choosing which; everywhere else both are on screen at once. |
| **Trends** | Periods, the long view, and overlaying periods to compare them.        |
| **Foods**  | The product database that feeds quick logging on Today.                |
| **More**   | Goals, body profile, the full data log, import/export, storage.        |

Desktop shows a navigation rail and unfolds each screen into two columns; below
900 px the same screens stack with a bottom tab bar. Nothing is added or removed
between the two — it is one layout that folds.

Today is the one exception, and only on Android: a phone has room for one metric
at a time, so there it splits into a Weight screen and an Eaten screen behind a
switch, and the Eaten screen is set in amber rather than green. The test is the
platform and not the window width (`LumaApp.is_android`) — a desktop window
dragged narrow crosses the breakpoint but is still not a phone, so it keeps both
metrics on screen.

## Layout of the code

```
app/
  main.py              entry point; resolves the data directory, builds the page
  luma/
    theme.py           every colour, size and radius from the design
    models.py          CalorieEntry, Category, FoodItem, Period, Settings
    store.py           persistence + every derived calculation (BMI, goals, periods)
    auth.py            Google sign-in, and the session that outlives a restart
    sync.py            the cloud copy: one file in Drive, kept level on every device
    reminders.py       the two reminders, and the alarms Android is given for them
    camera.py          the in-app shutter, on the phones that have one
    vision.py          reading a product's grams and calories off a photograph
    migrate.py         one-time import from the FitFriend web app
    xlsx_io.py         Excel export/import, compatible with the old exports
    charts.py          weight curve, calorie bars, comparison chart, drag/pinch-to-zoom
    ui.py              the shared widget vocabulary the screens compose from
    views/             today.py, trends.py, foods.py, more.py, account.py
  assets/icon.png      app icon
```

The UI layer holds no business rules. Anything that computes a number lives in
`store.py`, so the figures on screen match the original app exactly.

## Bringing your data across

**From the FitFriend web app** — More → *Import from FitFriend*. It accepts
either shape you can produce:

- the Drive app-data file `weight-tracker-data.json`, or
  `copy(localStorage.getItem('wt_data_v1'))` from DevTools
- a whole-localStorage dump, `copy(JSON.stringify(localStorage))`, which also
  carries the goal weight and active period that lived outside the database

Nothing is overwritten — incoming data is union-merged with what Luma already
holds, using the same rules the web app used when reconciling Drive.

**From a spreadsheet** — Trends → *Import*. Understands both the current
single-sheet export and the older three-sheet ("Weight Log" + "Calories")
layout. Re-importing the same file will not double-count a day.

## Defining a product from a photo

Foods → *New product* asks for a name, a portion in grams, and kcal per 100 g.
The third is the one nobody has: a menu gives the weight of what was ordered and
stops there, and the energy density of a piece of fried chicken is something a
person looks up rather than knows.

Type the name, fill in whichever number you do have, and press **Define by
photo**. Give it a photograph of the food and Gemini fills in what is missing.

On Android the shutter opens straight away — the food is on the table now, and
the alternative was three app switches to answer *what is in front of me*. The
sheet is a live preview, one button, and **Gallery** for a meal photographed an
hour ago. On Windows, and on a phone where the camera is unavailable or its
permission refused, the file picker opens instead; nothing here is ever a dead
end. Camera permission is asked for at the first shutter rather than at
start-up, and the microphone is never asked for at all.

- **A photo from the gallery is shown back before it is sent.** Android's
  picker hands the file over on the first tap of a thumbnail — there is nothing
  in it to confirm with — so Luma shows the photograph with **Cancel** and
  **Done** under it, and nothing leaves the phone until Done. A shot taken with
  the shutter goes straight through: pressing it was already the decision.
- **The name is required.** A photograph of fried chicken looks the same whether
  it came from a bucket or a bakery; the name is what says which. Pressing the
  button without one opens a window saying so and puts the caret back in the
  field — the only refusal here that stops you rather than passing in a line of
  text, because it is the only one you can do something about before the photo.
- **What you typed is never overwritten.** A known portion weight is handed over
  as fixed, and it comes back unchanged — what it does is tell the model the
  scale of what it is looking at, which is most of the guesswork gone. Only the
  empty field moves. With both filled in there is nothing to do, and the button
  says that instead of spending a request; clearing a field is how you ask again.
- **Nothing is known?** Then both come from the photograph and the name alone.
- **While it thinks**, the button says so and breathes — a slow fade in and out,
  since the wait is anywhere from two seconds to fifteen and has no percentage
  to show. `ui.Pulse` — the one wait long enough to need saying so, and the one
  the app answers by breathing rather than by spinning. (The account rows do use
  a ring, for the seconds a sign-in or a sync is actually in flight.)
- The toast that follows is the model's own sentence about what it decided it was
  looking at — a wrong guess gives itself away there, while the form is still
  open and every number in it is still editable.

Four models are tried in turn, newest first
(`gemini-3.7-flash` → `3.6-flash` → `3.5-flash` → `3.1-flash-lite`). One that is
rate-limited, out of quota or overloaded is stepped over, the next one down is
asked, and the one that refused is left alone for a minute and a half so the next
photo does not spend a round trip finding out the same thing. Only when the whole
list has refused does a window appear — everything else that can go wrong is
about this one attempt and passes in a line of text.

Every photo is shrunk on the device before it goes — 1280 px on the long side,
JPEG at quality 75, typically 150–300 KB. A meal needs none of the detail a
phone camera records, and the smaller photo uploads faster, costs fewer tokens,
and fits through the relay below. Pillow does it; without Pillow the photo goes
as it is.

Requests go through **the photo relay** in [`relay/`](../relay/README.md): one
Vercel function, pinned to a European region, that holds the Gemini key and
forwards the request to Google. Built apps carry only the relay's URL and token
(`LUMA_GEMINI_RELAY_URL`, `LUMA_GEMINI_RELAY_TOKEN`, stamped in at build time),
so the key is in no APK, and the token can be changed or the relay switched off
without touching the Google project. Google decides whether to serve the API by
the address a request arrives from, and sometimes places an address in the
wrong country; through the relay that address is Vercel's, not the phone's.

Without a relay, `LUMA_GEMINI_API_KEY` (or `GEMINI_API_KEY` in
`luma/credentials.py`) calls Google directly — handy from a checkout. **Unlike
the OAuth secret it sits next to, the key is a real credential**: whoever reads
it can spend the quota, so read the note at the bottom of that module before it
goes into a build. A build with neither is a working build: the button says so,
and the rest of Foods is untouched. All of it, and why, is in `luma/vision.py`.

The camera is `flet-camera` with `flet-permission-handler` in front of it, both
Android-only dependencies for the same reason `flet-android-notifications` is —
see `[tool.flet.android]` in pyproject.toml. `luma/camera.py` tests the platform
*before* it tests the import, because `flet-camera`'s control raises on Windows
rather than degrading, and a developer running `flet run` has the package
installed. To work on that screen from a desktop checkout:

```bash
pip install flet-camera==0.86.5 flet-permission-handler==0.86.5
```

which is only needed to satisfy an editor — the desktop path never reaches them.

## Reminders

Two, at the times the design fixed them at: the morning weigh-in at 08:00 and
*Kitchen closed* at 20:00, both switched on and off under More → *Reminders*.

Android raises them, and only Android. Luma hands it an alarm per reminder per
day for the week ahead, and tapping the notification opens the day it is about
— the weight screen for the weigh-in, Eaten for the kitchen. See *Android
notifications* below.

The app has no reminder of its own. It had one for a while — a card above the
tab bar, raised by a poll on the clock — and the trouble with it is that a
tracker is open for a minute a day: a nudge that can only arrive during that
minute arrives while you are already looking at the thing it is nudging you
towards.

So the two switches are switches on the phone's notifications. They are on the
desktop's More screen too, and they are a preference there rather than a dead
control: the settings document is synced, so a switch thrown on Windows is the
switch the phone reads the next time it arms its week.

The rules, all in `reminders.py`:

- **Answered reminders stay quiet.** A day already weighed in has nothing to
  ask for; a day already at its calorie goal has nothing left to close. Only
  today can be tested that way — nobody knows on Monday whether Thursday's
  weigh-in will have happened — so tomorrow's alarm is armed in ignorance and
  cancelled later, on a `sync` the app makes while it is open.
- **Today's alarm is dropped once its time has passed.** An alarm for eight
  o'clock armed at nine is one Android raises immediately, which is the one
  thing a reminder must never do.

The times live on the `Reminder` records, and More reads its captions from
them, so a caption cannot promise 08:00 over a scheduler holding something
else.

## Android notifications

Flet has no notification channel of its own, and Luma's Python runs in a
sandbox with no route to the Android APIs — `plyer` and `pyjnius` cannot reach
them from there. The bridge is a Flet extension:
[`flet-android-notifications`](https://pypi.org/project/flet-android-notifications/),
a Flutter package wrapping `flutter_local_notifications` with a Python service
in front of it. `flet build apk` finds it in site-packages and adds its Flutter
package to the build. `luma/notifications.py` is everything Luma does with it.

It is declared under `[tool.flet.android]` rather than `[project]`, so it ships
in the APK alone: the Windows build has no use for it and `flet run` cannot load
it at all. `Notifier` is written for that — off the phone the import fails, and
every call on it is a no-op rather than an error.

**When it is asked for.** Android 13 raises its permission dialog on the first
connection, so the connection is held back until the welcome screen is over —
`LumaApp.start_notifier`, released by `LumaApp.welcome_closed`. Answering it is
what lets the phone ask. Not simply `Settings.welcomed`: signing in on the
welcome screen pulls the account's settings down, that flag among them, and the
dialog would arrive over a screen still being read.

**What is armed.** One alarm per reminder per day for the next week, filed
under an id derived from its date, so re-arming a day replaces its alarm rather
than adding to it. `Notifier.sync` runs after anything that could change the
answer — a switch thrown, a weight logged, the app coming back to the
foreground — and returns without touching the phone unless the schedule it
computes differs from the one already armed. The week is re-extended to a full
week on every run, so a phone that is never opened keeps reminding for seven
days and then stops.

**What it cannot do.** The two tests that keep a reminder quiet need the
database, and nothing of Luma runs when the alarm fires. So they are applied to
today, when the app can know the answer, and not to the rest of the week: a
weigh-in logged at seven cancels this morning's alarm, and next Tuesday's is
cancelled next Tuesday. `Reminders.scheduled` is that rule.

**Where it can stop.** Every step is one Android can refuse, and none of them
stop the app — `Notifier.status` records how far it got, and what it decides is
whether there is anything to arm. Nothing on screen reports it: the switches on
More say what you asked for, and a phone that has had notifications switched
off for Luma in Android's own settings is answered there rather than here.

| Status        | What happened                                                      |
| ------------- | ------------------------------------------------------------------ |
| `off`         | Not a phone. The desktop schedules nothing.                        |
| `unavailable` | The extension is not in this build.                                |
| `blocked`     | Notifications are off for Luma in Android's settings. Re-checked every time the app returns to the foreground, so switching them back on is picked up without a restart. |
| `inexact`     | Armed, but exact alarms are not granted, so one can arrive late.   |
| `on`          | Armed, to the minute.                                              |

**Two things the build has to be told**, neither of which `flet build` can be
asked for — `patch-android-notifications.py` puts both back, the same way
`patch-launch-theme.py` puts back the launch theme:

- the two `flutter_local_notifications` receivers, in `AndroidManifest.xml`.
  Without the first, an alarm fires into nothing; without the second, every
  pending alarm is lost at the next restart.
- core library desugaring, in `build.gradle.kts`. The plugin is written against
  `java.time`, which the Android runtime does not have below API 26.

`build-apk.ps1` runs it before the build, over the project the last build left
behind — `flet build` re-renders that project only when the inputs it stamps
change, so on an ordinary rebuild the corrections are still there and one pass
is enough. On the **first** build of a fresh build directory there is nothing
to correct beforehand, so that build reaches Gradle uncorrected and Gradle
fails on the plugin. That is expected, and expected once: the corrections go on
afterwards and the second pass gets through.

**The icon in the status bar** is a third thing the build has to be told, and
`patch-notification-icon.py` is what tells it. Android paints the *alpha* of
the small icon and nothing else — every opaque pixel, in a colour it picks
itself. Left to the plugin's default of `@mipmap/ic_launcher`, that name
resolves on API 26 and later to the adaptive icon, whose background layer is a
solid `#0E1013`: opaque across the whole canvas, so the silhouette Android
takes from it is the canvas, and the status bar shows a white square.

So the notification has a drawable of its own — `notification.png` in the
repository root, the flame cut out of a disc — written into the generated
project at the five densities Android buckets a screen into, as
`res/drawable-*dpi/ic_stat_luma.png`. It is fitted to the middle 20 of the 24dp
a status bar icon is given, which is the margin Android's own icons keep, and
`notifications.SMALL_ICON` is the name that asks for it. Change either and the
other has to change with it: a name that resolves to no resource is not an
error the build reports.

## Signing in with Google

One sign-in, and the account is there every time the app opens — until you sign
out, which is the only thing besides Google itself revoking access that ends
it. More → *Account* is where it lives; the welcome screen offers it first.

On that screen the account answers the rest of it: signed in, the goal, the
calorie budget and the body profile are already in the account and the fields
asking for them go, leaving who is signed in, *Sign out* and *Start*. Signing
out there is the plain kind — nothing is removed and nothing is asked, because
the sign-in being undone was made on that screen a moment earlier — and the
form comes back carrying whatever the account left behind.

It is the flow OAuth defines for apps like this one — RFC 8252, authorization
code with PKCE, the system browser (a Custom Tab on Android), and a redirect to
a loopback server Luma opens on `127.0.0.1` for the length of the sign-in.
Flet's own `page.login()` is not used: in 0.86 its final step is implemented by
the web host alone, so it raises on both of the targets Luma ships to. All of
it, and why, is in `luma/auth.py`.

The session — refresh token, last access token, and the name and picture on
screen — is one file, `luma-auth.json`, beside the database. The profile is
read from it before the first frame, so the account is on screen immediately
and without a network round-trip; the access token is renewed in the background
when it has expired. A start-up with no network stays signed in. Only
`invalid_grant` — access revoked from the Google account's own settings, or a
grant left unused for six months — ends the session on Luma's side, and it says
so when it happens.

Signing out revokes the token at Google and deletes that file. What becomes of
the database beside it depends on whether anything else is holding a copy, and
the dialog asks it that way round.

**Syncing.** The account is carrying the data, so the file on this machine is a
cache of it and signing out clears the cache. Luma pushes whatever is still
waiting, and only if that round trip *finishes* does it empty the local copy;
sign in again, here or on another device, and all of it comes back. *Keep a
copy here*, on the same dialog, is the other way out — for a machine that is
your own and where the app should go on working signed out.

**Not syncing** — a session predating the Drive scope, or a build with no
client. Nothing is holding a second copy, so there is nothing to restore from,
nothing is removed, and the dialog says so.

The emptying is `Store.forget_local`, and it is pointedly not
`delete_everything`: it writes no tombstones. A tombstone is a deletion that
*travels*, so emptying this device with one would empty the account and every
other device behind it — the exact opposite of what signing out is being asked
for. The merge is a union and absence is never deletion, which is the whole
mechanism by which signing in again is a restore rather than an upload of
nothing. A sign-out that cannot reach Drive removes nothing and leaves the
session alone: emptying a disk on the strength of a cloud copy it never
confirmed is the one failure here that could not be undone.

The scopes are `openid`, `email`, `profile` and `drive.appdata` — who you are,
and one folder to keep your database in. `drive.appdata` is not access to your
Drive: it is a folder Google creates for Luma inside your account, which no
other app can read and which does not appear among your files. What it is for
is *Cloud sync*, below.

**A session made before sync existed cannot sync.** A token carries the scopes
that were consented to when it was issued, so an account signed in by an
earlier build has no Drive permission and no way to acquire one except another
trip to the consent screen. More says so and offers *Reconnect*.

### Giving a build a client

No OAuth client is committed here, so a fresh clone starts *unconfigured* —
More says so and offers the steps rather than a button that cannot work. To
give it one:

1. console.cloud.google.com → a project → **OAuth consent screen** (External;
   add yourself under *Test users*).
2. **Credentials → Create credentials → OAuth client ID → Desktop app.** It has
   to be the Desktop type: that is the one Google allows loopback redirects
   for, and it works for both the Windows build and the APK.
3. Give it to Luma, in any of the three places `auth.py` looks:
   - `LUMA_GOOGLE_CLIENT_ID` / `LUMA_GOOGLE_CLIENT_SECRET` in the environment,
     which is the convenient one for `flet run`;
   - the downloaded JSON saved as `google-client.json` in the data folder (the
     path is on the More screen);
   - `app/luma/google-client.json`, which is inside the Python payload both
     builds package — the only one of the three an installed app can carry.

Both files are in `.gitignore`. The client secret ships inside the app and is
not a secret in any meaningful sense, which is exactly why the flow is built on
PKCE — holding the secret is not what proves anything.

## Cloud sync

Sign in and the whole database — weights, calorie entries, notes, periods, the
product list, the goal weight, the body profile, the reminder switches — is
kept in your Google account and on every device signed into it. Install Luma on
a new phone, sign in, and it fills up; log a weight there and it is on the PC
when you next open it. All of it is `luma/sync.py`.

Luma stays local-first. Every write goes to disk first and nothing waits on a
network; the cloud gets a copy afterwards. Signed out, offline, or with Drive
refusing, the app is exactly the app it was — and whatever it missed goes out
when it can.

**The rules it follows:**

- **Pull, merge, push — in that order.** A device coming back has a local file
  and a remote one and neither is authoritative. `store.merge_data` unions them
  by the rules the web app already used, so two devices edited in turn never
  lose each other's work.
- **Deletions travel.** A union merge alone would hand a deleted day straight
  back the next time the other device synced, so a delete records a tombstone
  and a tombstone is carried in the document. Re-logging a deleted day beats
  its tombstone, because the revival is dated too and the later fact wins —
  `store.effective_tombstones`. Tombstones are pruned after 90 days.
- **One writer at a time.** Drive is told which revision each write is based on
  (`If-Match`); a device that lost the race gets a 412, re-pulls, merges and
  writes again rather than overwriting.
- **Pushes coalesce.** A change marks the store dirty and the loop sends the
  *current state* a couple of seconds later, so five foods logged in a row are
  one upload carrying all five.
- **Nothing can lose local data.** Every failure leaves the disk file alone;
  the status line says where it stands and the next attempt takes it from
  there. "Offline" and "Sync failed" are deliberately different words: one is
  the network, the other is Drive saying no.

Excel export/import is still there, and is still the way to move data without
an account.

## Building

Both builds need the pinned toolchain (JDK 17, the Android SDK, and the exact
Flutter version Flet expects). Two equivalent scripts set it up — use the one
that matches your shell.

**Android APK — PowerShell:**

```powershell
powershell -ExecutionPolicy Bypass -File build-apk.ps1
```

**Android APK — Git Bash:**

```bash
source build-env.sh && cd app && flet build apk
```

Windows PowerShell 5.1 has no `source`, `&&` or `yes`, so the bash form will not
work there — that is why `build-apk.ps1` exists.

Output lands in `app/build/apk/`. Two things the build needs on Windows:

- **Developer Mode must be on**, or Flutter cannot create plugin symlinks and
  the Gradle step fails. `start ms-settings:developers`. `build-apk.ps1` checks
  this first and tells you rather than failing halfway through.
- **Do not put another Flutter on PATH** ahead of the one under
  `~/flutter/<version>`. Flet pins a version and a newer SDK found first is
  used silently, then the build aborts on a version mismatch.

**Windows executable:**

```bash
cd app && flet build windows
```

This additionally needs Visual Studio with the "Desktop development with C++"
workload, which `flutter doctor` will confirm. It is not required for the APK,
and not required to run the app with `flet run`.

**Windows installer:**

```powershell
powershell -ExecutionPolicy Bypass -File build-installer.ps1 -Build
```

What `flet build windows` produces is a folder — `luma.exe` beside the Flutter
runtime, the Python runtime and the app — and the whole folder is the app.
`build-installer.ps1` wraps that folder in the single file people expect to be
handed, `app/build/installer/Luma-<version>-Setup.exe`, and prints its SHA256
for whoever downloads it. Without `-Build` it packages whatever the last
Windows build left behind, and refuses if that is older than the source beside
it or if `luma.exe` disagrees with pyproject about the version: a setup program
is the artifact most likely to be uploaded without being opened first.

This needs [Inno Setup 6](https://jrsoftware.org/isinfo.php) (6.3 or newer). It
is found on PATH, under Program Files, or by the registry entry Inno Setup's own
installer writes — which is what finds it on a machine that put it on another
drive. `LUMA_INNO_SETUP` overrides all three.

`installer/luma.iss` is the setup program itself and carries the reasoning:
per-user by default so installing Luma is not an administrative act, with the
dialog on the way in offering Program Files to anyone who would rather; an
upgrade that replaces the payload rather than merging with it; and an uninstall
that removes the app and deliberately not the database, which lives in the
account's application-support directory rather than beside the exe (see
`resolve_data_dir` in `main.py`).

`installer.png` is the setup program's own artwork — the flame in an open box,
which is not the app's icon and is not drawn by `make-icons.py`.
`make-installer-art.py` turns it into `installer/installer.ico` and the wizard's
images: the tall panel on the app's ink, and the header badge on white, each at
the sizes Inno Setup picks between for the display's scaling.
`build-installer.ps1` redraws them whenever the artwork is newer than they are.

## Notes on the port

- **Charts.** Flet has no built-in range zoom, so `charts.ZoomableChart` overlays
  a gesture detector and converts drag pixels into entry indices — the same
  drag-to-zoom the original had on its weight and comparison charts. A
  comparison has no shared index to zoom by, so `charts.CompareZoom` keeps its
  window in day offsets instead, the one x several periods share. It is the one
  chart a phone can zoom too: the whole touch goes to a single scale recogniser
  — one finger sideways picks a range, two close in on it — rather than a pan
  and a pinch competing with the page scrolling behind them.
- **Calories per day.** The bars cover the whole period the screen is set to —
  all time when no period is picked — rather than the last week or fortnight of
  it, and at most fourteen are drawn. Past that the days are *chosen* rather
  than averaged or cut: both ends of the run, the biggest day, the smallest,
  and then whatever is furthest from the calorie goal (from the median when no
  goal is set). Averaging adjacent days invented pairs of ordinary days that
  never happened and destroyed the two that mattered; keeping the last
  fortnight answered a question about a period with an answer about a
  fortnight. The caption says how many of how many, every bar is still one real
  day, and tapping one names it. See `charts._notable`.
- **Comparing periods.** A comparison scopes the screen to no single period,
  so the calorie bars are not drawn at all while one is up: "Calories per day"
  is a question about *a* period — whose days, whose average, against whose
  goal — and with none in focus it was answering about all time under two or
  three overlaid weight curves. Above the curves is a card per compared period
  — its line as the chart draws it, its name, what it moved — on both layouts
  now; touching one follows that period, drawing it solid while the others stay
  dotted.

  On the desktop the curves take the height the window has left, the same as
  the focused chart does. The phone has no window to take anything from, so its
  chart area is held to a height instead: the one measured off the arrangement
  with a period in focus (`TrendsView._phone_top`). A comparison stands in that
  same space — it has no hero and no calorie bars, so left to itself it arrived
  shorter than the arrangement it replaced and pulled the period list up the
  screen under the finger that had just ticked something. Inside the held box
  the legend is kept at the room the most that can be ticked would take
  (`_legend_height`) and the curves take the rest, both constant for every tick
  of a comparison. So a tick changes which curves are drawn and nothing else:
  not the size of the chart, not where it sits, not a pixel of the page below.
  Entering or leaving a comparison is the one change of size, and it is the
  curves that take it — a phone's comparison is taller than its single-period
  chart for the same reason the desktop's is. Two floors keep it honest: the
  box is never smaller than the card needs (`_compare_floor`), and a rotation
  drops the measurement rather than holding a portrait height in landscape.
- **The period pills.** The row folds behind "…" when what is on it will not
  stand on one line — measured in width, not in periods. Three periods called
  "The Second Great Weight Loss" are under any sane count and still three rows
  of chips on a phone, which is a chart pushed off the screen. Flutter is the
  only thing that knows what a string comes out at and it knows after the frame
  is drawn, so `ui.pill_width` estimates it from per-character advances. Room
  is kept for the "…" itself, and the pill the screen is scoped to is the last
  one given up — with a long enough name, "All time" goes behind the fold and
  it is what stays. The desktop keeps the plain count: its pills share a header
  with the title and three buttons, so the page's width is not theirs.
- **Baselines.** Flet's `Row` cannot do baseline cross-axis alignment (Flutter
  needs a `textBaseline` the control does not expose, and asking for it throws a
  layout error that blanks the frame). Large figures and their units are spans
  of a single `Text` instead, which baseline-aligns natively — see `ui.hero()`.
- **BMI strip.** The original drew the colour bands at raw BMI values (18.5%,
  25%, 30%) while positioning the marker on a 10–50 scale, so the pointer never
  agreed with the band beneath it. Both are derived from the same scale here.
- **Record ids.** The web app used a bare `Date.now()`, which collides when two
  records are created in the same millisecond. `models.new_id()` keeps the
  timestamp shape but bumps monotonically so ids stay unique.
- **The animated time-of-day background is gone.** That is the redesign's call,
  not an omission: "the background is one flat ink". The countdown timer and
  late-night banner moved to More as reminder settings — the banner itself
  survives as the *Kitchen closed* reminder, raised at 20:00 instead of drawn
  across the screen all evening.
